package com.focusmode.app.gamification

import kotlin.math.floor
import kotlin.math.sqrt

data class LevelProgress(
    val level: Int,
    val currentLevelBaseXp: Int,
    val nextLevelXp: Int,
    val progressPercent: Int,
    val xpRemaining: Int
)

object XpEngine {

    const val XP_STUDY_SESSION_25M = 25
    const val XP_CREATION_SESSION_40M = 40
    const val XP_URGE_CONTROL_10M = 15
    const val XP_WATER_LOG = 5
    const val XP_EXERCISE_LOG = 30
    const val XP_SLEEP_LOG = 20
    const val XP_HABIT_COMPLETION = 15
    const val XP_TASK_COMPLETION = 10

    /**
     * Transparent, deterministic Level formula:
     * Level L requires (L - 1)^2 * 50 XP
     * L = floor(sqrt(xp / 50)) + 1
     */
    fun calculateLevel(totalXp: Int): LevelProgress {
        val safeXp = totalXp.coerceAtLeast(0)
        val level = floor(sqrt(safeXp.toDouble() / 50.0)).toInt() + 1
        val currentLevelBase = (level - 1) * (level - 1) * 50
        val nextLevelThreshold = level * level * 50
        val range = nextLevelThreshold - currentLevelBase
        val progressInLevel = safeXp - currentLevelBase
        val percent = if (range > 0) ((progressInLevel.toFloat() / range.toFloat()) * 100).toInt().coerceIn(0, 100) else 100

        return LevelProgress(
            level = level,
            currentLevelBaseXp = currentLevelBase,
            nextLevelXp = nextLevelThreshold,
            progressPercent = percent,
            xpRemaining = (nextLevelThreshold - safeXp).coerceAtLeast(0)
        )
    }
}
