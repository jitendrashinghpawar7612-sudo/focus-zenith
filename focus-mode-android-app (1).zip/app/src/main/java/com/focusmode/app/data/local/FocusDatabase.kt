package com.focusmode.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.focusmode.app.data.local.dao.FocusDao
import com.focusmode.app.data.local.entity.*

@Database(
    entities = [
        FocusSessionEntity::class,
        AppLimitEntity::class,
        ReelsCounterEntity::class,
        HabitEntity::class,
        HabitCompletionEntity::class,
        WaterLogEntity::class,
        ExerciseLogEntity::class,
        SleepLogEntity::class,
        WeightLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class FocusDatabase : RoomDatabase() {
    abstract fun focusDao(): FocusDao

    companion object {
        @Volatile
        private var INSTANCE: FocusDatabase? = null

        fun getDatabase(context: Context): FocusDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FocusDatabase::class.java,
                    "focus_mode_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
